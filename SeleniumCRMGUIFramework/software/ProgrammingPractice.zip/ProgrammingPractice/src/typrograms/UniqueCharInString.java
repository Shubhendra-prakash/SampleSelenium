package typrograms;


public class UniqueCharInString {
	public static void main(String[] args) {
	String s ="abbcdeef";
		char []ch = s.toCharArray();
		for(int i=0; i<ch.length; i++)
		{
			int count =0;
			for(int j=0; j<ch.length; j++)
			{
				if(ch[i]==ch[j])
				{
					if(i>j)// if we not use this e will repeat 2times
					{
						break;
					}
					else
					{
						count++;
					}
				}
			}
			if(count==1)
			{
				System.out.println(ch[i]+"----"+count);
			}
		}
			
	}
}
