package typrograms;

public class SecontMin {
	public static void main(String[] args) {
		int []a= {2,3,1,6,4,5,5};
		int min1 =a[0];
		int min2 = a[1];
		for(int i=0; i<a.length; i++)
		{
			if(a[i]<min1)
			{
				min1=a[i];
			}
			else if (a[i]<min2)
			{
				min2=a[i];
			}
		}
	//	System.out.println("first minimum is "+min1);
		System.out.println("second minimum is "+min2);
	}
}
