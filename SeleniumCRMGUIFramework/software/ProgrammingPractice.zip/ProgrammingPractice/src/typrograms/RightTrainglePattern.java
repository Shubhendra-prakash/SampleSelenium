package typrograms;

public class RightTrainglePattern {
public static void main(String[] args) {
	int n=4;
	for(int i=0; i<n; i++)
	{
		for(int j=0; j<n; j++)
		{
			if(i>=j)
			{
				System.out.print("* ");
			}
			else {
				System.out.print("  ");
			}
		}
		System.out.println("");
	}
	
}
}
/*
 i>=j --->  right angle
*
* *
* * *
* * * *
------------------------
i+j<=n-1   right angle opp
* * * *
* * *
* *
* 
-------------------
i+j>=n-1 left angle
 	  *
	* *
  * * *
* * * *
------------------
i<=j  left angle opp
* * * *
  * * *
	* *
      * 
--------------------------
main for loop inside 2 for loops for 2nd loo j=1
pyramid
 	  *
    * * *
  * * * * *
* * * * * * *

*/