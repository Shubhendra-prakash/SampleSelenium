package typrograms;

public class SumOfDigitsInString
{
	public static void main(String[] args) {

		String s = "a1%23$65"; //17
		int sum =0;
		char [] ch = s.toCharArray();
		for(int i=0; i<ch.length; i++)
		{
			if(ch[i]>='0' && ch[i]<'9')
			{
				sum= sum+ch[i]-48;
			}
		}
		System.out.println(sum);
		
		//-------
		
		String s1 = "a1%23$65";
		int sum1=0;
		for(int i=0; i<s1.length(); i++)
		{
			int temp = s1.charAt(i);
			if(temp>='0' && temp<='9')
			{
				sum1 = sum1+temp-48;
			}
			
		}
		
		System.out.println(sum1);
		
		
		
		
		
		
		
		
		
	}
}
