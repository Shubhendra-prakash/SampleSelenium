package typrograms;

public class PalidromString {
public static void main(String[] args) {
	
	String s = "level";
	String rev="";
	for(int  i=s.length()-1; i>=0; i--)
	{
		rev = rev+ s.charAt(i);
		
	}
	
	if(s.equalsIgnoreCase(rev))
	{
		System.out.println(s+" is a palidrom");
		
	}
	else {
		System.out.println(s+" is not a palidrom");
	}
	
}
}
