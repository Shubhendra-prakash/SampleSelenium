package typrograms;

public class SecondMax {
public static void main(String[] args) {
	int []a= {2,3,1,6,4,5,5};
	
	int max1=a[0];
	int max2=a[1];
	
	for(int i=0; i<a.length; i++)
	{
		if(a[i]>max1)
		{
			max1=a[i];
		}
		else if (a[i]>max2) 
		{
			max2=a[i];
		}
		
	}
	//System.out.println("first max is "+max1);
	System.out.println("Second max is "+max2);
	
}
}
