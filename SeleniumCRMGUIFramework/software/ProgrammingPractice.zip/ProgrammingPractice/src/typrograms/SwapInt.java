package typrograms;

public class SwapInt {
	public static void main(String[] args) {
		int a=6;
		int b=5;
		System.out.println("before swapping");
		System.out.println("a--->"+a);
		System.out.println("b--->"+b);
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("after swapping");
		System.out.println("a--->"+a);
		System.out.println("b--->"+b);

	}
}
