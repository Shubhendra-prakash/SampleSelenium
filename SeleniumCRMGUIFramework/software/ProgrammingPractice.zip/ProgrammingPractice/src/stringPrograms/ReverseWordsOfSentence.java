package stringPrograms;

public class ReverseWordsOfSentence {

	public static void main(String[] args) {
		String s = "Hi Hello Welcome";
		String[] st = s.split(" ");

		for (int i = 0; i <= st.length - 1; i++) {

			String word = st[i] + " ";

			//reverse each word and "word" variable is reinitializing in every loop with new word
			for (int j = word.length() - 1; j >= 0; j--) {
				System.out.print(word.charAt(j) +"");
			}

	}
		
		
		
	}
}
