package stringPrograms;

import java.util.Iterator;

public class ReverseTheString {

	public static void main(String[] args) {
		String s="Abhay";
//		First way
		/*
		 * String rev= "";
		for(int i=s.length()-1;i>=0;i--) {
			rev=rev+s.charAt(i);
		}
		System.out.println(rev);
		 */
//		2nd way
		/*
		 * for(int i=s.length()-1;i>=0;i--) {
			System.out.print(s.charAt(i));
		}
		 */
//		3rd way
		
//		char[] ch=s.toCharArray();
//		for(int i=ch.length-1;i>=0;i--) {
//			System.out.print(ch[i]);
//		}
		
//		4th way
		StringBuffer sb = new StringBuffer(s);
		System.out.println(sb.reverse());
		

	}

}
