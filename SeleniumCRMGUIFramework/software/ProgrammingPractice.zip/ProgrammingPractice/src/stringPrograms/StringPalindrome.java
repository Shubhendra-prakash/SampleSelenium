package stringPrograms;

public class StringPalindrome {

	public static void main(String[] args) {

		String s="bingo";
		 String rev= "";
			for(int i=s.length()-1;i>=0;i--) {
				rev=rev+s.charAt(i);
			}
			if(rev.equalsIgnoreCase(s)) {
				System.out.println(s +":It is a Palindrome");
			}
			else {
				System.out.println(s +":It is not a Palindrome");
			}
	}

}
