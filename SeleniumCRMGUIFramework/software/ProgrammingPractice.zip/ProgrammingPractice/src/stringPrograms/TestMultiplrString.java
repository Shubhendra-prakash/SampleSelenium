package stringPrograms;

public class TestMultiplrString {

	public static void main(String[] args) {
		String s="my name is Abhay.i am working in ty.my name";
		String[] st = s.split("\\.");
		String rev="";
		String temp="";
		for(int i=0;i<st.length;i++) {
			String[] str = st[i].split(" ");
			if(i==0) {
				for(int j=str.length-1;j>=0;j--) {
					rev=rev+" "+str[j];
					
				}
			}
			else {
				temp=rev+" "+st[i]+" ";
			}
		}
		System.out.println(temp);

	}

}
