package stringPrograms;

public class ReverseTheStringOfSentence {

	public static void main(String[] args) {

		String s = "Hi Hello Funky Fellow";
		String[] st = s.split(" ");

		for (int i = st.length - 1; i >= 0; i--) {
			System.out.print(st[i] + " "); //Fellow Funky Hello Hi
		}
		
//		StringBuffer sb = new StringBuffer(s);
//		System.out.println(sb.reverse());
//		op: wolleF yknuF olleH iH
		
	}

}
