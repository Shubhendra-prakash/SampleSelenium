package stringPrograms;

public class AddOnlyNumbersInString {

	public static void main(String[] args) {
		String s = "saq1123hfdh339jh34h";

		int sum = 0;
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) >= '0' && s.charAt(i) <= '9') {
				System.out.print(s.charAt(i) + " ");
				int n = s.charAt(i) - 48;
				sum = sum + n;
			}

		}
		System.out.println(" Total sum=" + sum);

	}

}
