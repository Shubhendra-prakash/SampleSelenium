package stringPrograms;

public class StringPrograms1 {

	public static void main(String[] args) {
		String str="you are my friend";
		int count=0;
		String[] s = str.split(" ");
		for(int i=0; i<s.length;i++) {
			count++;
			System.out.print(s[i]+count);
		}

	}

}
