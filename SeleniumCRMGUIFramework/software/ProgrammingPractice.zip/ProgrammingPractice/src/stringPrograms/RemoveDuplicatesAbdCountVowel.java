package stringPrograms;

import java.util.LinkedHashSet;

public class RemoveDuplicatesAbdCountVowel {

	public static void main(String[] args) {
		String s = "India";
		String st = s.toLowerCase();

		LinkedHashSet<Character> set = new LinkedHashSet<Character>();
		for (int i = 0; i < st.length(); i++) {
			set.add(st.charAt(i));
		}
		int count = 0;
		for (Character c : set) {
			if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
				count++;
				System.out.print(c+" ");
			}

		}
		System.out.println(count);

	}
}
