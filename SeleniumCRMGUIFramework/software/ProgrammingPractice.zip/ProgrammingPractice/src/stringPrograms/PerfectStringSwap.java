package stringPrograms;

import java.util.Iterator;

public class PerfectStringSwap {

	public static void main(String[] args) {
		String st= "Hi Welcome to Bengalore";
		String[] s=st.split(" ");
//		int n = s.length;
//		
//		for(int i=n-1;i>=0;i--) {
//			System.out.print(s[i]+" ");
//		}
		
		System.out.println();
		String temp=s[0];
		
		for(int i=0;i<s.length;i++) {
			System.out.print(s[i]+" ");
		}

	}

}
