package stringPrograms;

import java.util.HashMap;
import java.util.Map.Entry;

public class OccuranceOfCharUsingMap {

	public static void main(String[] args) {
		String s="aabbabc";
//		String s1=s.toLowerCase();
//		char ch[]=s1.toCharArray();
//		HashMap<Character, Integer> map = new HashMap<Character, Integer>();
//		for(int i=0;i<ch.length;i++) {
//			if(map.containsKey(ch[i])) {
//				map.put(ch[i], map.get(ch[i])+1);
//			}
//			else {
//				map.put(ch[i], 1);
//			}
//		}
//		System.out.println(map);
//		
		
		String s1=s.toLowerCase();
		HashMap<Character, Integer> map = new HashMap<Character, Integer>();
		for(int i=0;i<s1.length();i++) {
			if(map.containsKey(s1.charAt(i))) {
				map.put(s1.charAt(i), map.get(s1.charAt(i))+1);
			}
			else {
				map.put(s1.charAt(i), 1);
			}
		}
		System.out.println(map);
		for (Entry<Character, Integer> entry : map.entrySet()) {
			System.out.print(entry.getKey()+""+entry.getValue());
			
		}
		

	}

}
