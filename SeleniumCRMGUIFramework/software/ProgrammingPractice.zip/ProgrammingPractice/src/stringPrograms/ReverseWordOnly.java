package stringPrograms;

public class ReverseWordOnly {

	public static void main(String[] args) {
		String s="I Love My Country";
		 String[] words = s.split(" ");
	        String result = "";

	        // Iterate through each word
	        for (int i = 0; i < words.length; i++) {
	            String word = words[i];
	            String reversedWord = "";

	            // Reverse the current word manually using a for loop
	            for (int j = word.length() - 1; j >= 0; j--) {
	                reversedWord += word.charAt(j);
	            }

	            // Add the reversed word to the result
	            result += reversedWord;

	            // Add a space after each word except the last one
	            if (i < words.length - 1) {
	                result += " ";
	            }
	        }

	        System.out.println(result);
	}

}
