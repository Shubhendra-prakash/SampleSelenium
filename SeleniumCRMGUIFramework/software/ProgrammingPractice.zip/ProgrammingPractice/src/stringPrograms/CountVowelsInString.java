package stringPrograms;

public class CountVowelsInString {

	public static void main(String[] args) {

		String st = "India";
		String sl = st.toLowerCase();

		char[] s = sl.toCharArray();
		int count = 0;
		for (int i = 0; i < st.length(); i++) {
			if (s[i] == 'a' || s[i] == 'e' || s[i] == 'i' || s[i] == 'o' || s[i] == 'u') {
				count++;
				System.out.print(s[i] + " ");
			}
		}
		System.out.println();
		System.out.println("Numbers of vowel in string-->" + count);
	}

}
