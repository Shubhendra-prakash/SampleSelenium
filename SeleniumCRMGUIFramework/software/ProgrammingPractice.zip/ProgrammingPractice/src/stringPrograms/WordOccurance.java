package stringPrograms;

import java.util.HashMap;

public class WordOccurance {

	public static void main(String[] args) {
		String s="I Am am From Bengalore";
		String sl=s.toLowerCase();
		String s1[]=sl.split(" ");
		HashMap<String, Integer> map = new HashMap<String, Integer>();
		for(int i=0;i<s1.length;i++) {
			if(map.containsKey(s1[i])) {
				map.put(s1[i], map.get(s1[i])+1);
			}
			else {
				map.put(s1[i], 1);
			}
		}
		System.out.println(map);

	}

}
