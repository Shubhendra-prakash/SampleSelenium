package stringPrograms;

public class StringPrograms2 {

	public static void main(String[] args) {
		String s="you are my favorite";
		String[] st = s.split(" ");
		for(int i=0;i<st.length;i++) {
			System.out.print(st[i]+""+st[i].length());
		}

	}

}
