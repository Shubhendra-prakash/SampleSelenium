package Arrayprograms;

public class AddArrays {

	public static void main(String[] args) {
		int[] a = { 4, 3, 1, 2, 5, 8, 7, 7, 6 };
		int[] b = { 3, 4, 6, 7, 8, 9, 8, 9 };
		int length = a.length;
		if (a.length < b.length) {
			length = b.length;
		}
		for (int i = 0; i < length; i++) {
			try {
				System.out.print(a[i] + b[i] + " ");
			} catch (Exception e) {
				if (a.length < b.length) {
					System.out.print(b[i] + " ");
				} else {
					System.out.print(a[i] + " ");

				}
			}
		}

	}

}
