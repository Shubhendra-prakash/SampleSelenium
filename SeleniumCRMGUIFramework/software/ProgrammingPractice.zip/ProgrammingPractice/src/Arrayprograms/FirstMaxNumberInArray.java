package Arrayprograms;

public class FirstMaxNumberInArray {
	public static void main(String[] args) {
		int arr[]= {20,10,22,30,22,12,90};
		int max=arr[0];
		for(int i=1;i<arr.length;i++) {
			if(arr[i]>max) {
				max=arr[i];
			}
		}
		System.out.println(max);
	}

}
