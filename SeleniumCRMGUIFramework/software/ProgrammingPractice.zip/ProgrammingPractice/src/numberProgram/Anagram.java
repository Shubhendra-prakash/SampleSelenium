package numberProgram;

import java.util.Arrays;

public class Anagram {

	public static void main(String[] args) {
		String p="Silent";
		String q="listen";
		String a=p.toLowerCase();
		String b=q.toLowerCase();
		char[] ch = a.toCharArray();
		char[] ch1 = b.toCharArray();
		Arrays.sort(ch);
		Arrays.sort(ch1);
		boolean res = Arrays.equals(ch, ch1);
		if(res) {
			System.out.println("Anagram");
		}
		else
			System.out.println("not anagram");
	}
}
