package numberProgram;

public class CheckPrimeOrNot {

	public static void main(String[] args) {
		int n = 7;
		boolean result = false;
		for (int i = 2; i <= n / 2; i++) {
			if (n % i == 0) {
				result = false;
			} else {
				result = true;
			}
		}
		if(result) {
			System.out.println(n+" Is a prime number");
		}
		else {
			System.out.println(n+" is not a prime number");
		}

	}

}
