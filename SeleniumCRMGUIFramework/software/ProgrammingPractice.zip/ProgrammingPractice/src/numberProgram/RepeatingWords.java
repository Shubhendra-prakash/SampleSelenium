package numberProgram;

public class RepeatingWords {

	public static void main(String[] args) {
		  String input = "carbustraincarbustrainbus";
	        String bus = "bus";
	        int count = 0;
	        int index = 0;

	        while ((index = input.indexOf(bus, index)) != -1) {
	            count++;
	            index = index+ bus.length();
	        }

	        System.out.println("The word bus is repeated " + count + " times.");
	    

	}

}
