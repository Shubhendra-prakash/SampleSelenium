package numberProgram;

public class Reasoning {

	public static void main(String[] args) {
	//o/p=1 3 7 15 31
		int a=0;
		
		for(int i=0;i<=5;i++) {
			a=a+(a+1);
			System.out.println(a+" ");
		}
		

	}

}
